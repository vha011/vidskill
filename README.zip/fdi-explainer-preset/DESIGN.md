# FDI & Geopolitical Explainer Preset (Finpath / Vox Style)

Preset đồ họa chuyển động dành cho video giải thích kinh tế, địa chính trị, tài chính và phân tích chuỗi cung ứng (phong cách Finpath, Vox, Johnny Harris).

## 1. Bảng Màu Nhận Diện (Color Palette)

- **Canvas Background**: Nền đen xám matte `#0A0D14` kết hợp lưới kỹ thuật đo lường (Dark Graph Grid).
- **Major Accent (Neon Lime)**: `#A3E635` (Viền glow lãnh thổ, điểm chốt số liệu, thẻ đạt chỉ tiêu).
- **Secondary Accent (Sun Gold)**: `#FACC15` (Mốc năm tháng, thanh tiến trình timeline, giá trị nổi bật).
- **Alert / Stamp Red**: `#EF4444` / `#DC2626` ("Bẫy thu nhập trung bình", con dấu "ĐÃ BÁN").
- **Contrast Text**: Trắng tinh `#FFFFFF` (Font sans-serif hình học đậm nét).
- **Secondary Text / Muted**: Xám bạc `#94A3B8` / `#64748B`.

## 2. Quy Chuẩn Typography

- Phông chữ tiêu đề & nội dung: **BeVietnamPro** (Bold 700, ExtraBold 800, Black 900) nhúng nội bộ, đảm bảo 100% không lệch chân hay méo dấu tiếng Việt.
- Phông chữ số liệu & năm: **Montserrat** (Font-weight 800-900).

## 3. Danh Mục 6 Thành Phần Motion Cốt Lõi (Motion Components)

1. **`TimelineRunner` (Trục thời gian chạy trên đỉnh)**:
   - Dải thước thời gian ngang (1967 ➔ 2026).
   - Biểu tượng ô tô / con trỏ trượt mượt mà theo tiến trình câu chuyện.
2. **`SatelliteMapGlow` (Bản đồ vệ tinh & Tuyến hàng hải)**:
   - Bản đồ thực địa độ tương phản cao.
   - Viền quốc gia nhấp nháy ánh sáng neon (pulse glow).
   - Tuyến đường hàng hải nét đứt nối các tọa độ.
3. **`CrateStackingChart` (Biểu đồ thùng hàng xếp tầng)**:
   - Thùng hàng xếp chồng lên nhau với độ nảy vật lý (`back.out(1.4)`).
   - Đường nối đỉnh đứt nét màu vàng neon thể hiện mức tăng trưởng (x100 lần).
4. **`CoinRatioComparison` (Đồng xu so sánh tỉ trọng)**:
   - 3 đồng xu bạc (NƯỚC NGOÀI) đối sánh 1 đồng xu xanh lá (VIỆT NAM).
   - Tag số liệu "77% FDI" nổi bật.
5. **`PolicyDecisionTree` (Sơ đồ cơ chế chính sách)**:
   - Hộp điều kiện có viền glow xanh lá: "CHỈ TIÊU XUẤT KHẨU" ➔ "TỪNG BỘ" ➔ "ĐẠT" ➔ "VỐN RẺ ƯU ĐÃI".
6. **`CutoutPaperStamp` (Cắt dán tài liệu & Con dấu)**:
   - Ảnh nhân vật / bài báo cắt viền trắng 3px, xoay góc nghiêng tự nhiên.
   - Con dấu "ĐÃ BÁN" đập xuống với âm thanh hit.
